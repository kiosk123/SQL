set serveroutput on
begin 
   for  i  in  1 .. 9 loop
     dbms_output.put_line ( '2 x ' ||  i  || ' = ' ||  2 * i ); 
   end loop;
end;
/
